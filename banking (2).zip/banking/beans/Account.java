package com.cg.banking.beans;

import com.cg.banking.beans.Transaction;

public class Account {
//	private  int ACCOUNT_IDX_COUNTER=0;
//	private  int ACCOUNT_ID_COUNTER=1;
	private int accountNo, accountBalance;
	private String accountType;
	private Transaction transaction[]; 
	public Account(){}
	public Account(int accountNo, int accountBalance, String accountType, Transaction[] transaction) {
		super();
		this.accountNo = accountNo;
		this.accountBalance = accountBalance;
		this.accountType = accountType;
		this.transaction = transaction;
	}
/*	public int getACCOUNT_IDX_COUNTER() {
		return ACCOUNT_IDX_COUNTER;
	}
	public void setACCOUNT_IDX_COUNTER(int aCCOUNT_IDX_COUNTER) {
		ACCOUNT_IDX_COUNTER = aCCOUNT_IDX_COUNTER;
	}
	public int getACCOUNT_ID_COUNTER() {
		return ACCOUNT_ID_COUNTER;
	}
	public void setACCOUNT_ID_COUNTER(int aCCOUNT_ID_COUNTER) {
		ACCOUNT_ID_COUNTER = aCCOUNT_ID_COUNTER;
	}*/
	public int getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(int accountNo) {
		this.accountNo = accountNo;
	}
	public int getAccountBalance() {
		return accountBalance;
	}
	public void setAccountBalance(int accountBalance) {
		this.accountBalance = accountBalance;
	}
	public String getAccountType() {
		return accountType;
	}
	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}
	public Transaction[] getTransaction() {
		return transaction;
	}
	public void setTransaction(Transaction[] transaction) {
		this.transaction = transaction;
	}
	
}