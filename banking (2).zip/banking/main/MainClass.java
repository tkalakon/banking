package com.cg.banking.main;

import com.cg.banking.beans.Address;
import com.cg.banking.beans.Customer;
import com.cg.banking.beans.Account;
import com.cg.banking.beans.Transaction;


public class MainClass {

	public static void main(String[] args) {
		Customer customer=new Customer();
		customer.setCustomerID(100);
//		Customer customer2 = new Customer(101,8125858858l,99999999l,"sindhu","kalakonda","a.com","sept 17","eu90922");
		System.out.println(customer.getCustomerID());
//		System.out.println(customer2.getCustomerID());
			
		Address address=new Address();
		address.setCity("Hyderabad");
		System.out.println(address.getCity());
		
		Account account =new Account();
		account.setAccountNo(812);
		System.out.println(account.getAccountNo());
		
		Transaction transaction =new Transaction();
		transaction.setTransactionID(800);
		System.out.println(transaction.getTransactionID());
					}
}



		
